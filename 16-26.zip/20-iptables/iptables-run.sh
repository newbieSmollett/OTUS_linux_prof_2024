#!/bin/sh

/sbin/iptables-restore < /etc/iptables_rules.ipv4
