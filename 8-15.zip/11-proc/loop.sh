#!/bin/bash

while true; do x=1; done
